package com.tavant.trainingspringbootjdbc.Repo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;



import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.tavant.trainingspringbootjdbc.Beans.User;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

@Repository
public class UserRepo {
    Scanner sc =new Scanner(System.in);
    @Autowired
    private JdbcTemplate jdbcTemp;

    public int getCountOfUsers() {
		return jdbcTemp.queryForObject(
				"select count(*) from user_details", 
				Integer.class);
	}

    public List<User> getAllUsers(){
		return jdbcTemp.query("select * from user_details",new RowMapper<User>() {
                 
                       @Override
                       public User mapRow(ResultSet rs, int rowNum) throws SQLException{
                           User theUser=new User();
                              theUser.setUserName(rs.getString("userName"));
                              theUser.setId(rs.getInt("Id"));
                              theUser.setUserAddress(rs.getString("userAddress"));
                              theUser.setPhone(rs.getString("phone")); 
                               return theUser;
                           }
                  
                  
                   });
        
	}
    public void insertUser(@RequestBody User user){
        jdbcTemp.update("insert into user_details(userName,userAddress,phone) values(?,?,?)",user.getUserName(),user.getUserAddress(),user.getPhone());
    }
    public void updateUser(@PathVariable int id,@RequestBody User user){
       
       
        jdbcTemp.update("update user_details set userName=?,userAddress=?,phone=? where Id=?", user.getUserName(),user.getUserAddress(),user.getPhone(), id);
    }
    public void deleteUser(@PathVariable int id){
        
        jdbcTemp.update("delete from user_details where id=?", id);
    }
}
