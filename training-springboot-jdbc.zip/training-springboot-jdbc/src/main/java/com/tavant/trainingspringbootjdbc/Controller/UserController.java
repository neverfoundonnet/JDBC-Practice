package com.tavant.trainingspringbootjdbc.Controller;


import java.util.List;

import com.tavant.trainingspringbootjdbc.Beans.User;
import com.tavant.trainingspringbootjdbc.Service.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("user")
public class UserController {
    @Autowired
    UserService serv;
    @GetMapping("/count")
	int getCountOfUsers() {
		return serv.getCountOfUsers();
	}
    @GetMapping("/users")
    List<User> getAllUsers(){
		
        return serv.getAllUsers();
	}

    @PostMapping("/insert")
    void insertUser(@RequestBody User user){
        serv.insertUser(user);
    }

    @PutMapping("/update/{id}")
    void updateUser(@PathVariable int id,@RequestBody User user){
        serv.updateUser(id,user);
    }
    @DeleteMapping("/delete/{id}")
    void deleteUser(@PathVariable int id){
        serv.deleteUser(id);
    }
}
