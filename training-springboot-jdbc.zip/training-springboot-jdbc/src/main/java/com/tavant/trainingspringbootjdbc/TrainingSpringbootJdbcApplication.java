package com.tavant.trainingspringbootjdbc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrainingSpringbootJdbcApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrainingSpringbootJdbcApplication.class, args);
	}

}
