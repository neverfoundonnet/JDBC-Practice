package com.tavant.trainingspringbootjdbc.Service;

import java.util.List;

import com.tavant.trainingspringbootjdbc.Beans.User;
import com.tavant.trainingspringbootjdbc.Repo.UserRepo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

@Service
public class UserService {
   @Autowired
   UserRepo repo;
   public int getCountOfUsers() {
        return repo.getCountOfUsers();
    }
    public void updateUser(@PathVariable int id,@RequestBody User user){
        repo.updateUser(id,user);
    }
    public void deleteUser(@PathVariable int id){
        repo.deleteUser(id);
    }
    public List<User> getAllUsers(){
        return repo.getAllUsers();
    }
   public void insertUser(@RequestBody User user){
       repo.insertUser(user);
   }

}
