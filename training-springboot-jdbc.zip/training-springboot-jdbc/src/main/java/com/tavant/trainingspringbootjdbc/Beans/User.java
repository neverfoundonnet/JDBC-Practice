package com.tavant.trainingspringbootjdbc.Beans;

public class User {
    private int Id;
    private String userName;
    private String userAddress;
    private String phone;
    
    public User() {

    }
    
    public User(int id, String userName, String userAddress, String phone) {
        Id = id;
        this.userName = userName;
        this.userAddress = userAddress;
        this.phone = phone;
    }

    public int getId() {
        return Id;
    }
    public void setId(int id) {
        Id = id;
    }
    public String getUserName() {
        return userName;
    }
    public void setUserName(String userName) {
        this.userName = userName;
    }
    public String getUserAddress() {
        return userAddress;
    }
    public void setUserAddress(String userAddress) {
        this.userAddress = userAddress;
    }
    public String getPhone() {
        return phone;
    }
    public void setPhone(String phone) {
        this.phone = phone;
    }

    @Override
    public String toString() {
        return "User [Id=" + Id + ", phone=" + phone + ", userAddress=" + userAddress + ", userName=" + userName + "]";
    }
    
    
}
