package com.tavant.trainingspringbootjdbc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrainingSpringbootJdbcApplicationTests {

	@Test
	void contextLoads() {
	}

}
