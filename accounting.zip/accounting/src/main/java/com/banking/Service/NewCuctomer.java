package com.banking.Service;

import java.util.Scanner;

import com.banking.Component.Account;
import com.banking.Component.Customer;
import com.banking.Repository.Connections;

public class NewCuctomer {
   
    public void newCuctomer(){
		Connections cs=new Connections();
                Scanner sc=new Scanner(System.in);
                System.out.println("Enter the Details of the  customer:\n");
				System.out.println("Name of the customer: ");
				String name= sc.next();
				System.out.println("Gender of the customer: ");
				String gender= sc.next();
				System.out.println("Age of the customer: ");
				int age= sc.nextInt();
				System.out.println("Pin of the customer: ");
				int pin= sc.nextInt();

		Customer c =new Customer(name, gender, age, pin);
		if(cs.createCustomer(c)){
			int id=0;
			System.out.println("New customer id is: "+id);
			System.out.println("\nNow creating an account for that customer..\n");
			System.out.println("Enter the following details:\n");
			System.out.println("Account number: ");
			String accNo=sc.next();
			System.out.println("Account balance: ");
			int accBal=sc.nextInt();
			System.out.println("Account Type: ");
			String accType=sc.next();
			int accId=id;
			Account a=new Account(accId, accNo,  accBal, accType);
			if(cs.createAccount(a,c)){
				System.out.println("Account created successfully!\n");
			}
			else
				System.out.println("Problem with creating account!");
		}
		else
			System.out.println("Problem with creating Customer and acount!\n");
                
    }
    
    
}
