package com.banking.Service;

import java.sql.SQLException;
import java.util.Scanner;

public class Choice {
    public void picChoice() throws ClassNotFoundException, SQLException{
        int choice;
	    Scanner sc=new Scanner(System.in);
	    boolean exiting=false;
	    while(!exiting){
	        System.out.println("\nEnter your choice:\n1: New customer:\n2: Customer Login\n3:exit\n");
	        choice=sc.nextInt();
            switch (choice) {
                case 1:
                    new NewCuctomer().newCuctomer();
                    break;
                case 2:
                    new Login().login();
                    break;
                case 3:
                    exiting=true;
                    break;
            }
        }
    }
}
