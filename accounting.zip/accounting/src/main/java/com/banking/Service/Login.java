package com.banking.Service;

import java.util.Scanner;

import com.banking.Component.Account;
import com.banking.Component.Customer;
import com.banking.Repository.Connections;

public class Login {
    Scanner sc=new Scanner(System.in);
    void login(){
        System.out.println("Enter customer id and pin to login:\n");
		int cust_id=sc.nextInt();
		int cust_pin=sc.nextInt();
        Connections cs=new Connections();
        if(cs.checkLogin(cust_id, cust_pin)){
            System.out.println("Enter the choice: \n");
				System.out.println("1:Check balance\n2:Transfer Funds\n3:Withdrawal Balance\n4:Change pin\n");
				int desire=sc.nextInt();
				switch (desire) {
					case 1:
                        Account a = new Account();
						a=cs.checkBalance(cust_id);
                        System.out.println("Current balance is: "+a.getAccountBalance());
						break;
				
					case 2:
						System.out.println("Enter the account number of the receipent:\n");
						String rec_acc=sc.next();
						System.out.println("Enter the name of the receipent:\n");
						String rec_name=sc.next();
						System.out.println("enter the amount to be transferred: ");
						int amt=sc.nextInt();
                        cs.transferFund(rec_acc, rec_name, amt, cust_id);
						break;
					case 3:
						System.out.println("Enter the amount to be Withdrawal: ");
						int w_amt=sc.nextInt();
						cs.withdrawalMoney(w_amt,cust_id);
						
						break;
					case 4:
						System.out.println("Enter the new pin: ");
						int pin=sc.nextInt();
						cs.changePin(pin, cust_id);
						
						break;
					
                }
        }

    }
}
