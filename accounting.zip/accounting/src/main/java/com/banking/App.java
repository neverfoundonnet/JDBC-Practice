package com.banking;

import java.sql.SQLException;


import com.banking.Service.Choice;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public final class App {
   

   
    public static void main(String[] args) throws ClassNotFoundException, SQLException {
        ApplicationContext theContext = new ClassPathXmlApplicationContext("config.xml");
        Choice c=new Choice();
        c.picChoice();
    }
}
