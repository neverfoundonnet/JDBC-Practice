package com.banking.Repository;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.banking.Component.Account;
import com.banking.Component.Customer;

public class Connections {
	static String qry;
	Connection dbCon;
	
	Statement theStatement;
	public Connections(){
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection dbCon=DriverManager.getConnection("jdbc:mysql://localhost:3306/banking", "root", "root");
			System.out.println("connected!");
			theStatement = dbCon.createStatement();
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
	}
	public boolean createCustomer(Customer c){
		qry="insert into Customer (custName,custGender,custAge,custPin) values ("+ "'"
		+ c.getCustName() + "', '"
		+ c.getCustGender() + "', '" 
        + c.getCustAge() + "', '" 
		+ c.getCustPin() + "')";
		
		
		try {
            
			if(theStatement.executeUpdate(qry) > 0)
				return true;
			} catch (SQLException e) {
			System.out.println("Issues with creating customer: " + e.getMessage());
		}
		return false;
	}

	public boolean createAccount(Account a,Customer c){
		int id=0;
		qry="select Id from Customer where custName='"+c.getCustName()+"' and custPin='"+c.getCustPin()+"'";
		try {
			ResultSet rs=theStatement.executeQuery(qry);
			
			while(rs.next()){
				id=rs.getInt("Id");
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		qry="insert into Account (accNumber,accId,accBalance,accType) values ("+ "'"
		+ a.getAccountNumber() + "', '"
		+ id + "', '" 
		+ a.getAccountBalance() + "', '" 
		+ a.getAccountType() + "')";

       
        
		try {
			if(theStatement.executeUpdate(qry) > 0)
				return true;
			} catch (SQLException e) {
			System.out.println("Issues with dynamic added user query : " + e.getMessage());
		}
		return false;
		
	}
	public boolean checkLogin(int custId,int custPin){
		qry="select Id,custPin,custName from Customer where Id='"+custId+"' and custPin='"+custPin+"'";
			try {
				ResultSet rs = theStatement.executeQuery(qry);
				rs.next();
					System.out.println(rs.getInt("Id"));
					System.out.println(rs.getInt("custPin"));
					System.out.println(rs.getString("custName"));
					if(custId==rs.getInt("Id") && custPin==rs.getInt("custPin")){
						System.out.println("login successful for: "+rs.getString("custName")+"!");
						return true;
					}
					else{
						System.out.println("Wrong credentials!");
					}
				
			} catch (SQLException e) {
				System.out.println("login failed!");
				e.printStackTrace();
			}
		
		
		return false;
	}
	public Account checkBalance(int cust_id){
		Account a=new Account();
		qry="select A.accBalance from Account A,Customer C where A.accId='"+cust_id+"'";
		try {
			ResultSet rs=theStatement.executeQuery(qry);
			rs.next();
			a.setAccountBalance(rs.getInt("accBalance"));
			//System.out.println("Current balance is: "+rs.getInt("accBalance"));
		} catch (SQLException e) {
						
			e.printStackTrace();
		}
		return a;
	}
	public void transferFund(String rec_acc,String rec_name,int amt,int cust_id){
		qry="select A.* from Account A,Customer C where A.accNumber='"+rec_acc+"' and C.custName='"+rec_name+"' and A.accId=C.Id";
					try {
						ResultSet rs=theStatement.executeQuery(qry);
						//rs.next();
						if(rs.next()){
							int temp1=rs.getInt("accId");
							
							qry="select A.accBalance from Account A, Customer C where C.Id='"+cust_id+"' and A.accId=C.Id";
							ResultSet rse=theStatement.executeQuery(qry);
							rse.next();
							int temp=rse.getInt("accBalance");
							if(temp>=amt){
								qry="update Account set accBalance=accBalance-'"+amt+"' where accId='"+cust_id+"'";
								theStatement.executeUpdate(qry);
								System.out.println("Amount has been deducted from sender's account..");
								System.out.println("-------Processing-------");
								qry="update Account set accBalance=accBalance+'"+amt+"' where accId='"+temp1+"'";
								theStatement.executeUpdate(qry);
								System.out.println("Amount has been added to the receipent's account");
							}
							else{
								System.out.println("insufficient fund!");
							}
						}
					} catch (SQLException e) {
						
						e.printStackTrace();
					}
	}
	public void withdrawalMoney(int amt,int cust_id){
		qry="select A.accBalance from Account A,Customer C where A.accId='"+cust_id+"'";
					
					try {
						ResultSet rs1 = theStatement.executeQuery(qry);
						rs1.next();
						if(amt<=rs1.getInt("accBalance")){
							
							qry="update Account set accBalance=accBalance-'"+amt+"' where accId='"+cust_id+"'";
							theStatement.executeUpdate(qry);
							System.out.println("The money has been withdrawn!");
						}
						else{
							System.out.println("Insufficient fund!");
						}
					} catch (SQLException e) {
						
						e.printStackTrace();
					}
					
	}
	public void changePin(int pin,int cust_id){
		qry="update Customer set custPin='"+pin+"' where Id='"+cust_id+"'";
					try {
						theStatement.executeUpdate(qry);
						System.out.println("Pin has been changed successfully!");
					} catch (SQLException e) {
						
						e.printStackTrace();
					}
	}
   
}

