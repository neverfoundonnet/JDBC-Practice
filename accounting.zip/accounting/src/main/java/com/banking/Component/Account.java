package com.banking.Component;

public class Account {
    private int accountId;
   
    private String accountNumber;
    private int accountBalance;
    private String accountType;
    
    public Account() {

    }
    
    public Account(int accountId, String accountNumber, int accountBalance, String accountType) {
        this.accountId = accountId;
        this.accountNumber = accountNumber;
        this.accountBalance = accountBalance;
        this.accountType = accountType;
    }

    public int getAccountId() {
        return accountId;
    }

    public void setAccountId(int accountId) {
        this.accountId = accountId;
    }

    public String getAccountNumber() {
        return accountNumber;
    }
    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }
    public int getAccountBalance() {
        return accountBalance;
    }
    public void setAccountBalance(int accountBalance) {
        this.accountBalance = accountBalance;
    }
    public String getAccountType() {
        return accountType;
    }
    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }
    @Override
    public String toString() {
        return "Account [accountBalance=" + accountBalance + ", accountId=" + accountId + ", accountNumber="
                + accountNumber + ", accountType=" + accountType + "]";
    }
    
}
