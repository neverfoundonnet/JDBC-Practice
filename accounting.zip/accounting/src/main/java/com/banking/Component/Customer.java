package com.banking.Component;

public class Customer {
    private String custName;
    private String custGender;
    private int custAge;
    private int custPin;
    
    public Customer() {
        
    }
    public Customer(String custName, String custGender, int custAge, int custPin) {
        this.custName = custName;
        this.custGender = custGender;
        this.custAge = custAge;
        this.custPin = custPin;
    }
    public String getCustName() {
        return custName;
    }
    public void setCustName(String custName) {
        this.custName = custName;
    }
    public String getCustGender() {
        return custGender;
    }
    public void setCustGender(String custGender) {
        this.custGender = custGender;
    }
    public int getCustAge() {
        return custAge;
    }
    public void setCustAge(int custAge) {
        this.custAge = custAge;
    }
    public int getCustPin() {
        return custPin;
    }
    public void setCustPin(int custPin) {
        this.custPin = custPin;
    }
    @Override
    public String toString() {
        return "Customer [custAge=" + custAge + ", custGender=" + custGender + ", custName=" + custName + ", custPin="
                + custPin + "]";
    }
    
}
